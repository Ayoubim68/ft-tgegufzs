import static java.lang.System.exit;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.*;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;


public class Pauvocoder {

    final static int SEQUENCE = StdAudio.SAMPLE_RATE / 10;
    final static int OVERLAP = SEQUENCE / 5;
    final static int SEEK_WINDOW = 3 * OVERLAP / 4;

    public static void main(String[] args) {
        if (args.length == 2) {
            processCommandLine(args);
        } else {
            SwingUtilities.invokeLater(Pauvocoder::createAndShowGUI);
        }
    }

    private static void processCommandLine(String[] args) {
        if (args.length < 2) {
            System.out.println("usage: java Pauvocoder <input.wav> <freqScale>");
            System.exit(1);
        }

        String wavInFile = args[0];
        double freqScale = Double.parseDouble(args[1]);

        // Vérification de la plage de fréquence
        if (freqScale < 0.25 || freqScale > 4.0) {
            System.out.println("La fréquence doit être comprise entre 0.25 et 4.0");
            System.exit(1);
        }

        String outPutFile = wavInFile.split("\\.")[0] + "_" + freqScale + "_";

        double[] inputWav = StdAudio.read(wavInFile);

        // Calcul de la nouvelle longueur pour préserver la durée
        int newLength = (int)(inputWav.length / freqScale);
        double[] newPitchWav = resample(inputWav, freqScale, newLength);
        StdAudio.save(outPutFile + "Resampled.wav", newPitchWav);

        double[] outputWav = vocodeSimple(newPitchWav, freqScale);
        StdAudio.save(outPutFile + "Simple.wav", outputWav);

        outputWav = vocodeSimpleOver(newPitchWav, freqScale);
        StdAudio.save(outPutFile + "SimpleOver.wav", outputWav);

        outputWav = vocodeSimpleOverCross(newPitchWav, freqScale);
        StdAudio.save(outPutFile + "SimpleOverCross.wav", outputWav);

        StdAudio.play(outputWav);

        outputWav = echo(outputWav, 100, 0.7);
        StdAudio.save(outPutFile + "SimpleOverCrossEcho.wav", outputWav);

        displayWaveform(outputWav);

        System.out.println("Durée originale : " + inputWav.length / (double)StdAudio.SAMPLE_RATE + " secondes");
        System.out.println("Durée rééchantillonnée : " + newPitchWav.length / (double)StdAudio.SAMPLE_RATE + " secondes");
        System.out.println("Durée traitée : " + outputWav.length / (double)StdAudio.SAMPLE_RATE + " secondes");
    }

    public static double[] resample(double[] input, double freqScale, int newLength) {
        double[] output = new double[newLength];

        for (int i = 0; i < newLength; i++) {
            double position = i * freqScale;
            int lowIndex = (int) Math.floor(position);
            int highIndex = (int) Math.ceil(position);

            // Gestion des limites du tableau
            if (lowIndex >= input.length) {
                lowIndex = input.length - 1;
            }
            if (highIndex >= input.length) {
                highIndex = input.length - 1;
            }

            // Interpolation linéaire
            double fraction = position - lowIndex;
            output[i] = (1 - fraction) * input[lowIndex] + fraction * input[highIndex];
        }

        return output;
    }

    public static double[] vocodeSimple(double[] input, double freqScale) {
        int outputLength = (int)(input.length * freqScale);
        double[] output = new double[outputLength];

        for (int i = 0; i < outputLength; i++) {
            double inputIndex = i / freqScale;
            int index = (int) inputIndex;
            if (index < input.length - 1) {
                double fraction = inputIndex - index;
                output[i] = (1 - fraction) * input[index] + fraction * input[index + 1];
            } else if (index < input.length) {
                output[i] = input[index];
            }
        }

        return output;
    }

    public static double[] vocodeSimpleOver(double[] input, double freqScale) {
        int outputLength = (int)(input.length * freqScale);
        double[] output = new double[outputLength];

        for (int i = 0; i < outputLength; i += SEQUENCE) {
            double inputStart = i / freqScale;
            for (int j = 0; j < SEQUENCE && i + j < outputLength; j++) {
                double inputIndex = inputStart + j / freqScale;
                int index = (int) inputIndex;
                if (index < input.length - 1) {
                    double fraction = inputIndex - index;
                    output[i + j] = (1 - fraction) * input[index] + fraction * input[index + 1];
                } else if (index < input.length) {
                    output[i + j] = input[index];
                }
            }
        }

        return output;
    }

    public static double[] vocodeSimpleOverCross(double[] input, double freqScale) {
        int outputLength = (int)(input.length * freqScale);
        double[] output = new double[outputLength];

        for (int i = 0; i < outputLength; i += SEQUENCE) {
            double inputStart = i / freqScale;
            int bestOffset = findBestOffset(input, (int)inputStart, input.length);

            for (int j = 0; j < SEQUENCE && i + j < outputLength; j++) {
                double inputIndex = inputStart + (bestOffset + j) / freqScale;
                int index = (int) inputIndex;
                if (index < input.length - 1) {
                    double fraction = inputIndex - index;
                    output[i + j] = (1 - fraction) * input[index] + fraction * input[index + 1];
                } else if (index < input.length) {
                    output[i + j] = input[index];
                }
            }
        }

        return output;
    }

    private static int findBestOffset(double[] input, int start, int inputLength) {
        int bestOffset = 0;
        double bestCorrelation = Double.NEGATIVE_INFINITY;

        // Protection contre les dépassements de tableau
        if (start < 0) start = 0;
        if (start >= inputLength) start = inputLength - 1;

        int maxOffset = Math.min(SEEK_WINDOW, inputLength - start - SEQUENCE);
        maxOffset = Math.max(0, maxOffset); // S'assurer que maxOffset n'est pas négatif

        for (int offset = 0; offset < maxOffset; offset++) {
            if (start + offset + SEQUENCE >= inputLength) break;

            double correlation = 0;
            int maxJ = Math.min(OVERLAP, inputLength - start - offset - SEQUENCE);

            for (int j = 0; j < maxJ; j++) {
                correlation += input[start + j] * input[start + offset + SEQUENCE + j];
            }

            if (correlation > bestCorrelation) {
                bestCorrelation = correlation;
                bestOffset = offset;
            }
        }

        return bestOffset;
    }

    public static double[] echo(double[] input, double delay, double decay) {
        int delayInSamples = (int) (delay * StdAudio.SAMPLE_RATE / 1000);
        double[] output = new double[input.length];

        for (int i = 0; i < input.length; i++) {
            output[i] = input[i];
            if (i >= delayInSamples) {
                output[i] += decay * input[i - delayInSamples];
            }
        }

        return output;
    }

    public static void displayWaveform(double[] wav) {
        StdDraw.setCanvasSize(800, 400);
        StdDraw.setXscale(0, wav.length);
        StdDraw.setYscale(-1.0, 1.0);

        for (int i = 1; i < wav.length; i++) {
            StdDraw.line(i-1, wav[i-1], i, wav[i]);
        }
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Pauvocoder");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Main panel with some padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // File input section
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(new JLabel("Fichier d'entrée:"), gbc);

        JTextField filePathField = new JTextField();
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        mainPanel.add(filePathField, gbc);

        JButton chooseFileButton = new JButton("Choisir un fichier");
        gbc.gridy = 2;
        mainPanel.add(chooseFileButton, gbc);

        // Parameters section
        gbc.gridwidth = 1;
        gbc.gridy = 3;
        mainPanel.add(new JLabel("Facteur de fréquence:"), gbc);

        JTextField freqScaleField = new JTextField("1.0");
        gbc.gridy = 4;
        mainPanel.add(freqScaleField, gbc);

        gbc.gridy = 5;
        mainPanel.add(new JLabel("Facteur de temps:"), gbc);

        JTextField timeFactorField = new JTextField("1.0");
        gbc.gridy = 6;
        mainPanel.add(timeFactorField, gbc);

        gbc.gridy = 7;
        mainPanel.add(new JLabel("Délai d'écho (ms):"), gbc);

        JTextField echoDelayField = new JTextField("100");
        gbc.gridy = 8;
        mainPanel.add(echoDelayField, gbc);

        gbc.gridy = 9;
        mainPanel.add(new JLabel("Atténuation d'écho:"), gbc);

        JTextField echoDecayField = new JTextField("0.7");
        gbc.gridy = 10;
        mainPanel.add(echoDecayField, gbc);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        JButton processButton = new JButton("Traiter");
        JButton playButton = new JButton("Jouer");
        JButton displayButton = new JButton("Afficher");

        buttonPanel.add(playButton);
        buttonPanel.add(displayButton);

        gbc.gridy = 11;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        mainPanel.add(processButton, gbc);

        gbc.gridy = 12;
        mainPanel.add(buttonPanel, gbc);

        // Event handlers
        chooseFileButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
                filePathField.setText(chooser.getSelectedFile().getPath());
            }
        });

        processButton.addActionListener(e -> {
            try {
                String filePath = filePathField.getText();
                double freqScale = Double.parseDouble(freqScaleField.getText());

                if (freqScale < 0.25 || freqScale > 4.0) {
                    JOptionPane.showMessageDialog(frame,
                            "La fréquence doit être comprise entre 0.25 et 4.0",
                            "Erreur",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double echoDelay = Double.parseDouble(echoDelayField.getText());
                double echoDecay = Double.parseDouble(echoDecayField.getText());

                double[] inputWav = StdAudio.read(filePath);
                int newLength = (int)(inputWav.length / freqScale);
                double[] newPitchWav = resample(inputWav, freqScale, newLength);
                double[] outputWav = vocodeSimpleOverCross(newPitchWav, freqScale);
                outputWav = echo(outputWav, echoDelay, echoDecay);

                String outPutFile = filePath.split("\\.")[0] + "_processed.wav";
                StdAudio.save(outPutFile, outputWav);
                displayWaveform(outputWav);

                JOptionPane.showMessageDialog(frame, "Traitement terminé: " + outPutFile);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame,
                        "Erreur lors du traitement: " + ex.getMessage(),
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        playButton.addActionListener(e -> {
            try {
                String filePath = filePathField.getText();
                if (!filePath.isEmpty()) {
                    double[] audio = StdAudio.read(filePath);
                    StdAudio.play(audio);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame,
                        "Erreur lors de la lecture: " + ex.getMessage(),
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        displayButton.addActionListener(e -> {
            try {
                String filePath = filePathField.getText();
                if (!filePath.isEmpty()) {
                    double[] audio = StdAudio.read(filePath);
                    displayWaveform(audio);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame,
                        "Erreur lors de l'affichage: " + ex.getMessage(),
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        frame.add(mainPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

