DROP TABLE IF EXISTS recupere;
DROP TABLE IF EXISTS Transport;
DROP TABLE IF EXISTS Tournee;
DROP TABLE IF EXISTS Vehicule;
DROP TABLE IF EXISTS Centre_de_Tri;
DROP TABLE IF EXISTS Ville;
DROP TABLE IF EXISTS Types_de_Vehicule;
DROP TABLE IF EXISTS Usine_de_recyclage;
DROP TABLE IF EXISTS Societe_de_ramassage_recyclage;
DROP TABLE IF EXISTS Type_de_Dechets;


CREATE TABLE Type_de_Dechets(
   id_typeDeDechets INT AUTO_INCREMENT,
   Nom_dechet VARCHAR(50),
   PRIMARY KEY(id_typeDeDechets)
);

CREATE TABLE Societe_de_ramassage_recyclage(
   id_societe INT AUTO_INCREMENT,
   Nom_Societe VARCHAR(50),
   Adresse_societe VARCHAR(50),
   PRIMARY KEY(id_societe)
);

CREATE TABLE Usine_de_recyclage(
   id_usine INT AUTO_INCREMENT,
   Nom_usineDeRecyclage VARCHAR(50),
   Adresse_UsineDeRecyclage VARCHAR(50),
   PRIMARY KEY(id_usine)
);

CREATE TABLE Types_de_Vehicule(
   idTypesVehicule INT AUTO_INCREMENT,
   libelleTypeVehicule VARCHAR(50),
   PRIMARY KEY(idTypesVehicule)
);

CREATE TABLE Ville(
   IdVille INT AUTO_INCREMENT,
   Nom VARCHAR(50),
   PRIMARY KEY(IdVille)
);

CREATE TABLE Vehicule(
   id_vehicule INT AUTO_INCREMENT,
   Capacite INT,
   Date_entretien DATE,
   idTypesVehicule INT NOT NULL,
   id_societe INT NOT NULL,
   PRIMARY KEY(id_vehicule),
   FOREIGN KEY(idTypesVehicule) REFERENCES Types_de_Vehicule(idTypesVehicule),
   FOREIGN KEY(id_societe) REFERENCES Societe_de_ramassage_recyclage(id_societe)
);

CREATE TABLE Centre_de_Tri(
   id_centreDeTri INT AUTO_INCREMENT,
   Nom_centreDeTri VARCHAR(50),
   Adresse_centreDeTri VARCHAR(50),
   PoidsDechet VARCHAR(50),
   IdVille INT  NOT NULL,
   PRIMARY KEY(id_centreDeTri),
   FOREIGN KEY(IdVille) REFERENCES Ville(IdVille)
);

CREATE TABLE Tournee(
   id_tournee INT AUTO_INCREMENT,
   Heure_Debut TIME,
   Heure_Fin TIME,
   PoidsTotal VARCHAR(50),
   Date_tournee DATE,
   id_usine INT NOT NULL,
   id_vehicule INT NOT NULL,
   PRIMARY KEY(id_tournee),
   FOREIGN KEY(id_usine) REFERENCES Usine_de_recyclage(id_usine),
   FOREIGN KEY(id_vehicule) REFERENCES Vehicule(id_vehicule)
);

CREATE TABLE Transport(
   IdTransport INT AUTO_INCREMENT,
   Poids DECIMAL(15,2),
   id_typeDeDechets INT NOT NULL,
   id_tournee INT NOT NULL,
   PRIMARY KEY(IdTransport),
   FOREIGN KEY(id_typeDeDechets) REFERENCES Type_de_Dechets(id_typeDeDechets),
   FOREIGN KEY(id_tournee) REFERENCES Tournee(id_tournee)
);

CREATE TABLE recupere(
   id_centreDeTri INT,
   id_tournee INT,
   ordre_de_tournee INT,
   PRIMARY KEY(id_centreDeTri, id_tournee),
   FOREIGN KEY(id_centreDeTri) REFERENCES Centre_de_Tri(id_centreDeTri),
   FOREIGN KEY(id_tournee) REFERENCES Tournee(id_tournee)
);


-- Table Type_de_Dechets
INSERT INTO Type_de_Dechets (id_typeDeDechets, Nom_dechet) VALUES
(NULL, 'Plastique'),
(NULL, 'Verre'),
(NULL, 'Métal'),
(NULL, 'Papier');

-- Table Societe_de_ramassage_recyclage
INSERT INTO Societe_de_ramassage_recyclage (id_societe, Nom_Societe, Adresse_societe) VALUES
(NULL, 'EcoRamassage', '12 Rue Verte'),
(NULL, 'CleanUp', '45 Avenue Bleue');

-- Table Usine_de_recyclage
INSERT INTO Usine_de_recyclage (id_usine, Nom_usineDeRecyclage, Adresse_UsineDeRecyclage) VALUES
(NULL, 'Usine Alpha', 'Zone Industrielle 1'),
(NULL, 'Usine Beta', 'Zone Industrielle 2');

-- Table Types_de_Vehicule
INSERT INTO Types_de_Vehicule (idTypesVehicule, libelleTypeVehicule) VALUES
(NULL, 'Véhicule Léger'),
(NULL, 'Poids Lourd'),
(NULL, 'Électrique');

-- Table Ville
INSERT INTO Ville (IdVille, Nom) VALUES
(NULL, 'Paris'),
(NULL, 'Lyon'),
(NULL, 'Marseille');

-- Table Vehicule
INSERT INTO Vehicule (id_vehicule, Capacite, Date_entretien, idTypesVehicule, id_societe) VALUES
(NULL, 1500.50, '2024-01-15', 2, 1),
(NULL, 800.00, '2024-02-10', 1, 2),
(NULL, 1200.75, '2024-03-05', 3, 1);

-- Table Centre_de_Tri
INSERT INTO Centre_de_Tri (id_centreDeTri, Nom_centreDeTri, Adresse_centreDeTri, PoidsDechet, IdVille) VALUES
(NULL, 'TriCentral', '5 Rue des Déchets', '250kg', 1),
(NULL, 'TriSud', '8 Avenue du Sud', '400kg', 2),
(NULL, 'TriNord', '22 Boulevard du Nord', '320kg', 3);

-- Table Tournee
INSERT INTO Tournee (id_tournee, Heure_Debut, Heure_Fin, PoidsTotal, Date_tournee, id_usine, id_vehicule) VALUES
(NULL, '08:00:00', '12:00:00', '1500kg', '2024-11-20', 1, 1),
(NULL, '13:00:00', '17:00:00', '800kg', '2024-11-21', 2, 2),
(NULL, '09:00:00', '15:00:00', '1200kg', '2024-11-22', 1, 3);

-- Table Transport
INSERT INTO Transport (IdTransport, Poids, id_typeDeDechets, id_tournee) VALUES
(NULL, 500.25, 1, 1),
(NULL, 300.75, 2, 2),
(NULL, 700.50, 3, 3);

-- Table recupere
INSERT INTO recupere (id_centreDeTri, id_tournee, ordre_de_tournee) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1);