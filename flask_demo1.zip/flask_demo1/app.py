#! /usr/bin/python
# -*- coding:utf-8 -*-
from tokenize import group

from flask import Flask, request, render_template, redirect, flash

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.secret_key = 'une cle(token) : grain de sel(any random string)'

                                    ## à ajouter
from flask import session, g
import pymysql.cursors

def get_db():
    if 'db' not in g:
        g.db =  pymysql.connect(
            host="serveurmysql",                 # à modifier
            user="achakiri",           # à modifier
            password="mdp",                # à modifier
            database="BDD_achakiri",        # à modifier
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )
    return g.db

@app.teardown_appcontext
def teardown_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

@app.route('/')
@app.route('/Transport/show')
def show_Transport():
    mycursor = get_db().cursor()
    sql = '''   SELECT IdTransport AS id, Poids AS Poids, id_tournee AS id_tournee,Nom_dechet FROM Transport JOIN Type_de_Dechets ON Transport.id_typeDeDechets=Type_de_Dechets.id_typeDeDechets  ORDER BY Poids;      '''
    mycursor.execute(sql)
    liste_Transport = mycursor.fetchall()
    sql_etat = '''   
              SELECT Type_de_Dechets.Nom_dechet AS nom_dechet,SUM(Transport.Poids) AS poids_total_dechet,Transport.id_tournee AS id_tournee
              FROM Transport
              JOIN Type_de_Dechets ON Transport.id_typeDeDechets = Type_de_Dechets.id_typeDeDechets
            GROUP BY Type_de_Dechets.id_typeDeDechets, Type_de_Dechets.Nom_dechet, Transport.id_tournee
              ORDER BY Transport.id_tournee, Type_de_Dechets.id_typeDeDechets;  
          '''
    mycursor.execute(sql_etat)
    liste_dechets = mycursor.fetchall()

    return render_template('Transport/show_Transport.html', Transport=liste_Transport)



@app.route('/Transport/add', methods=['GET'])
def add_Transport():
    print('''affichage du formulaire pour saisir un Transport''')
    mycursor = get_db().cursor()
    sql = '''SELECT id_typeDeDechets , Nom_dechet FROM Type_de_Dechets'''
    mycursor.execute(sql)
    Type_de_Dechets= mycursor.fetchall()
    sql_Tournee = '''SELECT id_tournee FROM Tournee'''
    mycursor.execute(sql_Tournee)
    tournee = mycursor.fetchall()
    return render_template('Transport/add_Transport.html', Type_de_Dechets=Type_de_Dechets, Tournee=tournee)

@app.route('/Transport/delete')
def delete_Transport():
    print('''suppression d'un Transport''')
    print(request.args)
    print(request.args.get('id'))
    id=request.args.get('id')
    mycursor = get_db().cursor()
    sql = '''   DELETE FROM Transport WHERE IdTransport=%s;
      '''
    tuple_del = (id)
    mycursor.execute(sql,tuple_del)
    get_db().commit()
    flash(f'Transport avec ID {id} supprimé avec succès', 'danger')
    return redirect('/Transport/show')

@app.route('/Transport/edit', methods=['GET'])
def edit_Transport():
    print('''affichage du formulaire pour modifier un Transport''')
    print(request.args.get('id'))
    id=request.args.get('id')
    if id != None and id.isnumeric():
        indice = int(id)
        mycursor = get_db().cursor()
        sql = '''   SELECT IdTransport AS id, Poids AS Poids, id_tournee, id_typeDeDechets AS id_typeDeDechets
FROM Transport
WHERE IdTransport=%s;     '''
        mycursor.execute(sql,(id))
        Transport = mycursor.fetchone()

        # Ajout des requêtes pour les listes déroulantes
        sql_types = '''SELECT id_typeDeDechets, Nom_dechet FROM Type_de_Dechets'''
        mycursor.execute(sql_types)
        Type_de_Dechets = mycursor.fetchall()

        print("Type_de_Dechets:", Type_de_Dechets)

        sql_tournee = '''SELECT id_tournee FROM Tournee'''
        mycursor.execute(sql_tournee)
        Tournee = mycursor.fetchall()

        print("Tournee:", Tournee)

    else:
        Transport=[]
        Type_de_Dechets = []
        Tournee = []
    return render_template('Transport/edit_Transport.html', Transport=Transport, Type_de_Dechets=Type_de_Dechets, Tournee=Tournee)



@app.route('/Transport/add', methods=['POST'])
def valid_add_Transport():
    print('''ajout de le Transport dans le tableau''')
    Poids = request.form.get('Poids')
    id_typeDeDechets = request.form.get('id_typeDeDechets')
    id_tournee = request.form.get('id_tournee')
    Nom_dechet = request.form.get('nom_dechet')
    message = f'Transport ajouté avec succès. Poids : {Poids}, Type de déchets : {id_typeDeDechets}, Tournée : {id_tournee}'
    print(message)
    mycursor = get_db().cursor()
    sql='''   INSERT INTO Transport(IdTransport, Poids, id_typeDeDechets,id_Tournee) VALUES (NULL, %s, %s, %s);
      '''
    tuple_insert=(Poids,id_typeDeDechets,id_tournee)
    mycursor.execute(sql,tuple_insert)
    get_db().commit()
    print(message)
    flash(message, 'success')
    return redirect('/Transport/show')

@app.route('/Transport/edit', methods=['POST'])
def valid_edit_Transport():
    print('''modification du Transport dans le tableau''')
    id = request.form.get('id')
    Poids = request.form.get('Poids')
    id_typeDeDechets = request.form.get('id_typeDeDechets')
    id_Tournee = request.form.get('id_Tournee')
    message = f'Poids : {Poids} - id_typeDeDechets : {id_typeDeDechets} - id_Tournee : {id_Tournee} pour le Transport d identifiant : {id}'
    print(message)
    mycursor = get_db().cursor()
    sql = '''UPDATE Transport SET Poids = %s, id_tournee = %s, id_typeDeDechets = %s WHERE IdTransport = %s;'''
    tuple_ed = (Poids, id_Tournee, id_typeDeDechets, id)
    mycursor.execute(sql, tuple_ed)
    get_db().commit()
    flash(message, 'success')
    return redirect('/Transport/show')

@app.route('/')
@app.route('/Transport/etat')
def etat_Transport():
    mycursor = get_db().cursor()
    sql_etat = '''
            SELECT 
                td.Nom_dechet AS nom_dechet,
                COUNT(t.IdTransport) AS nombre_transports,
                SUM(t.Poids) AS poids_total,
                ROUND(AVG(t.Poids), 2) AS poids_moyen,
                COUNT(DISTINCT t.id_tournee) AS nombre_tournees,
                ROUND(SUM(t.Poids) / COUNT(DISTINCT t.id_tournee), 2) AS poids_moyen_par_tournee,
                ROUND((SUM(t.Poids) * 100.0 / (SELECT SUM(Poids) FROM Transport)), 2) AS pourcentage_poids_total,
                ROUND(STDDEV_POP(t.Poids), 2) AS ecart_type_poids
            FROM Transport t
            JOIN Type_de_Dechets td ON t.id_typeDeDechets = td.id_typeDeDechets
            GROUP BY td.id_typeDeDechets, td.Nom_dechet
            ORDER BY poids_total DESC;
        '''
    mycursor.execute(sql_etat)
    stats_dechets = mycursor.fetchall()

    sql_query = """
    SELECT 
        v.id_vehicule AS id_vehicule,
        tv.libelleTypeVehicule AS type_vehicule,
        COUNT(t.IdTransport) AS nombre_transports,
        SUM(t.Poids) AS poids_total,
        ROUND(AVG(t.Poids), 2) AS poids_moyen,
        ROUND(SUM(t.Poids) / v.Capacite, 2) AS taux_utilisation_capacite
    FROM 
        Transport t
        JOIN Tournee tr ON t.id_tournee = tr.id_tournee
        JOIN Vehicule v ON tr.id_vehicule = v.id_vehicule
        JOIN Types_de_Vehicule tv ON v.idTypesVehicule = tv.idTypesVehicule
    GROUP BY 
        v.id_vehicule, tv.libelleTypeVehicule
    ORDER BY 
        poids_total DESC;
    """
    mycursor.execute(sql_query)
    stats_vehicules = mycursor.fetchall()

    return render_template(
        'Transport/etat_Transport.html',
        Transport=stats_dechets,
        Vehicules=stats_vehicules
    )

if __name__ == '__main__':
    app.run(debug=True, port=5000)
